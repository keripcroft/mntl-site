Put photos in this folder with these exact names:
  hero.jpg     - top of page (wide, dark/moody garage shot; at least 2000px wide)
  closing.jpg  - bottom of page (wide garage still)
  keri.jpg     - About section (tall/portrait, direct to camera)
  share.png    - link preview image (already included, 1200x630)
Keep each photo under about 500 KB so the page loads fast (squoosh.app can shrink them).
